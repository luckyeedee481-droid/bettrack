# Bet Tracker — Backend

FastAPI + SQLAlchemy + PostgreSQL backend for the bet tracking & analytics platform.

## Setup

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # then edit DATABASE_URL if needed
```

## Database

This project uses Alembic for migrations. The initial migration
(`app/migrations/versions/45cc94edf960_initial_schema.py`) creates all 16
core tables from the ERD: users, sports, competitions, teams, events,
markets, bookmakers, bets, bet_selections, slips, slip_images, ocr_results,
followers, comments, likes, notifications.

```bash
# create the DB (Postgres must be running)
createdb bet_tracker

# apply migrations
export DATABASE_URL=postgresql+psycopg://postgres:postgres@localhost:5432/bet_tracker
alembic upgrade head
```

To generate a new migration after changing models in `app/models/`:

```bash
alembic revision --autogenerate -m "describe your change"
```

**Note on enums:** Postgres ENUM types are separate objects from the tables
that use them. When you add a new enum column, double check the generated
downgrade includes a corresponding `sa.Enum(name=...).drop(...)` — Alembic's
autogenerate does not add this automatically, and without it a
downgrade→upgrade cycle will fail with "type already exists".

## Running locally

```bash
uvicorn app.main:app --reload
```

Then visit `http://localhost:8000/health` and `http://localhost:8000/docs`.

## Deploying to Render

1. Create a Render PostgreSQL instance, copy its **Internal Database URL**.
2. Set it as `DATABASE_URL` in your web service's environment variables.
3. Build command: `pip install -r requirements.txt`
4. Start command: `alembic upgrade head && uvicorn app.main:app --host 0.0.0.0 --port $PORT`

## Folder structure

```
app/
  api/            # route handlers (FastAPI routers), grouped by domain
  models/         # SQLAlchemy ORM models (this is the ERD)
  schemas/        # Pydantic request/response schemas
  services/       # business logic, separate from route handlers
  workers/        # background jobs: sports updater, settlement, OCR, stats, notifications
  database/       # engine/session setup
  analytics/       # analytics computation
  notifications/  # notification dispatch logic
  ocr/            # slip image -> text/structured data pipeline
  sports/         # sports-data-provider integration
  utils/
  tests/
  migrations/     # Alembic
```

## Roadmap (per architecture doc)

1. ✅ Project setup
2. ✅ Database schema
3. ⬜ Authentication
4. ⬜ Manual bet tracking MVP
5. ⬜ Automatic result engine
6. ⬜ Analytics
7. ⬜ Social features
8. ⬜ OCR
9. ⬜ Premium features
