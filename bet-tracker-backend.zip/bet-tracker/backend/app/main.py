from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(
    title="Bet Tracker API",
    version="0.1.0",
    description="Backend for the bet tracking & analytics platform.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten this to your Angular app's origin before production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health", tags=["meta"])
def health_check():
    return {"status": "ok"}


# Routers get included here as they're built, e.g.:
# from app.api import auth, bets, slips
# app.include_router(auth.router, prefix="/api/auth", tags=["auth"])
# app.include_router(bets.router, prefix="/api/bets", tags=["bets"])
