import enum
import uuid
from typing import List, Optional
from datetime import datetime

from sqlalchemy import String, ForeignKey, DateTime, Integer, Enum as SAEnum
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.session import Base
from app.models.mixins import UUIDPrimaryKeyMixin, TimestampMixin


class EventStatus(str, enum.Enum):
    SCHEDULED = "scheduled"
    LIVE = "live"
    FINISHED = "finished"
    POSTPONED = "postponed"
    CANCELLED = "cancelled"


class Sport(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "sports"

    name: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    slug: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)

    competitions: Mapped[List["Competition"]] = relationship(back_populates="sport")
    teams: Mapped[List["Team"]] = relationship(back_populates="sport")


class Competition(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "competitions"

    sport_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("sports.id"), nullable=False)
    name: Mapped[str] = mapped_column(String(128), nullable=False)
    country: Mapped[Optional[str]] = mapped_column(String(64))
    season: Mapped[Optional[str]] = mapped_column(String(16))

    sport: Mapped["Sport"] = relationship(back_populates="competitions")
    events: Mapped[List["Event"]] = relationship(back_populates="competition")


class Team(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "teams"

    sport_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("sports.id"), nullable=False)
    name: Mapped[str] = mapped_column(String(128), nullable=False)
    short_name: Mapped[Optional[str]] = mapped_column(String(32))
    logo_url: Mapped[Optional[str]] = mapped_column(String(512))

    sport: Mapped["Sport"] = relationship(back_populates="teams")


class Event(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """A single match/fixture within a competition."""
    __tablename__ = "events"

    competition_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("competitions.id"), nullable=False
    )
    home_team_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("teams.id"), nullable=False)
    away_team_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("teams.id"), nullable=False)

    start_time: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False, index=True)
    status: Mapped[EventStatus] = mapped_column(
        SAEnum(EventStatus, name="event_status"), default=EventStatus.SCHEDULED, nullable=False
    )
    home_score: Mapped[Optional[int]] = mapped_column(Integer)
    away_score: Mapped[Optional[int]] = mapped_column(Integer)

    # external sports-data-provider ID, used by the sports updater worker to
    # reconcile fixtures without relying on internal UUIDs
    external_ref: Mapped[Optional[str]] = mapped_column(String(128), index=True)

    competition: Mapped["Competition"] = relationship(back_populates="events")
    home_team: Mapped["Team"] = relationship(foreign_keys=[home_team_id])
    away_team: Mapped["Team"] = relationship(foreign_keys=[away_team_id])
    markets: Mapped[List["Market"]] = relationship(back_populates="event")


class Market(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """A specific bettable market on an event, e.g. 'Match Winner', 'Over/Under 2.5'."""
    __tablename__ = "markets"

    event_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("events.id"), nullable=False)
    market_type: Mapped[str] = mapped_column(String(64), nullable=False)
    name: Mapped[str] = mapped_column(String(128), nullable=False)

    event: Mapped["Event"] = relationship(back_populates="markets")


class Bookmaker(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "bookmakers"

    name: Mapped[str] = mapped_column(String(128), unique=True, nullable=False)
    logo_url: Mapped[Optional[str]] = mapped_column(String(512))
    website: Mapped[Optional[str]] = mapped_column(String(255))
