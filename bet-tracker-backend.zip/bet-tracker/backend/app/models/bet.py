import enum
import uuid
from typing import List, Optional
from datetime import datetime

from sqlalchemy import String, ForeignKey, DateTime, Numeric, Enum as SAEnum, Float, JSON, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.session import Base
from app.models.mixins import UUIDPrimaryKeyMixin, TimestampMixin


class BetStatus(str, enum.Enum):
    PENDING = "pending"
    WON = "won"
    LOST = "lost"
    VOID = "void"
    CASHED_OUT = "cashed_out"
    PARTIALLY_WON = "partially_won"  # e.g. system/multiple bets with mixed selection results


class BetType(str, enum.Enum):
    SINGLE = "single"
    MULTIPLE = "multiple"  # accumulator / parlay
    SYSTEM = "system"


class SelectionResult(str, enum.Enum):
    PENDING = "pending"
    WON = "won"
    LOST = "lost"
    VOID = "void"


class SlipStatus(str, enum.Enum):
    UPLOADED = "uploaded"
    PROCESSING = "processing"
    PARSED = "parsed"
    NEEDS_REVIEW = "needs_review"
    LINKED = "linked"  # successfully linked to a Bet
    FAILED = "failed"


class Bet(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "bets"

    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    bookmaker_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("bookmakers.id")
    )

    bet_type: Mapped[BetType] = mapped_column(SAEnum(BetType, name="bet_type"), nullable=False)
    stake: Mapped[float] = mapped_column(Numeric(12, 2), nullable=False)
    total_odds: Mapped[float] = mapped_column(Numeric(10, 3), nullable=False)
    potential_return: Mapped[float] = mapped_column(Numeric(12, 2), nullable=False)
    actual_return: Mapped[Optional[float]] = mapped_column(Numeric(12, 2))
    currency: Mapped[str] = mapped_column(String(8), default="NGN", nullable=False)

    status: Mapped[BetStatus] = mapped_column(
        SAEnum(BetStatus, name="bet_status"), default=BetStatus.PENDING, nullable=False, index=True
    )
    placed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    settled_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))

    is_public: Mapped[bool] = mapped_column(default=True, nullable=False)

    user: Mapped["User"] = relationship(back_populates="bets")
    bookmaker: Mapped[Optional["Bookmaker"]] = relationship()
    selections: Mapped[List["BetSelection"]] = relationship(
        back_populates="bet", cascade="all, delete-orphan"
    )
    slip: Mapped[Optional["Slip"]] = relationship(back_populates="bet", uselist=False)
    comments: Mapped[List["Comment"]] = relationship(back_populates="bet", cascade="all, delete-orphan")
    likes: Mapped[List["Like"]] = relationship(back_populates="bet", cascade="all, delete-orphan")


class BetSelection(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """One leg of a bet (single bets have exactly one; multiples have several)."""
    __tablename__ = "bet_selections"

    bet_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("bets.id"), nullable=False)
    event_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("events.id"))
    market_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("markets.id"))

    selection_name: Mapped[str] = mapped_column(String(255), nullable=False)
    odds: Mapped[float] = mapped_column(Numeric(10, 3), nullable=False)
    result: Mapped[SelectionResult] = mapped_column(
        SAEnum(SelectionResult, name="selection_result"), default=SelectionResult.PENDING, nullable=False
    )

    bet: Mapped["Bet"] = relationship(back_populates="selections")
    event: Mapped[Optional["Event"]] = relationship()
    market: Mapped[Optional["Market"]] = relationship()


class Slip(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """An uploaded betting-slip record, optionally linked to a parsed Bet."""
    __tablename__ = "slips"

    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    bet_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("bets.id"))

    status: Mapped[SlipStatus] = mapped_column(
        SAEnum(SlipStatus, name="slip_status"), default=SlipStatus.UPLOADED, nullable=False
    )

    user: Mapped["User"] = relationship(back_populates="slips")
    bet: Mapped[Optional["Bet"]] = relationship(back_populates="slip")
    images: Mapped[List["SlipImage"]] = relationship(back_populates="slip", cascade="all, delete-orphan")


class SlipImage(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "slip_images"

    slip_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("slips.id"), nullable=False)
    file_path: Mapped[str] = mapped_column(String(512), nullable=False)
    content_type: Mapped[Optional[str]] = mapped_column(String(64))

    slip: Mapped["Slip"] = relationship(back_populates="images")
    ocr_result: Mapped[Optional["OCRResult"]] = relationship(
        back_populates="slip_image", uselist=False, cascade="all, delete-orphan"
    )


class OCRResult(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "ocr_results"

    slip_image_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("slip_images.id"), nullable=False, unique=True
    )
    raw_text: Mapped[Optional[str]] = mapped_column(Text)
    parsed_data: Mapped[Optional[dict]] = mapped_column(JSON)
    confidence: Mapped[Optional[float]] = mapped_column(Float)
    processed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))

    slip_image: Mapped["SlipImage"] = relationship(back_populates="ocr_result")
