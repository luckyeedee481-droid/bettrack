import enum
import uuid
from typing import Optional

from sqlalchemy import ForeignKey, String, Text, Boolean, UniqueConstraint, Enum as SAEnum
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.session import Base
from app.models.mixins import UUIDPrimaryKeyMixin, TimestampMixin


class NotificationType(str, enum.Enum):
    BET_SETTLED = "bet_settled"
    NEW_FOLLOWER = "new_follower"
    NEW_COMMENT = "new_comment"
    NEW_LIKE = "new_like"
    SLIP_PROCESSED = "slip_processed"
    SYSTEM = "system"


class Follower(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    """follower_id follows followed_id."""
    __tablename__ = "followers"
    __table_args__ = (UniqueConstraint("follower_id", "followed_id", name="uq_follower_pair"),)

    follower_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    followed_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)

    follower: Mapped["User"] = relationship(foreign_keys=[follower_id])
    followed: Mapped["User"] = relationship(foreign_keys=[followed_id])


class Comment(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "comments"

    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    bet_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("bets.id"), nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)

    user: Mapped["User"] = relationship(back_populates="comments")
    bet: Mapped["Bet"] = relationship(back_populates="comments")


class Like(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "likes"
    __table_args__ = (UniqueConstraint("user_id", "bet_id", name="uq_like_pair"),)

    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    bet_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("bets.id"), nullable=False)

    user: Mapped["User"] = relationship(back_populates="likes")
    bet: Mapped["Bet"] = relationship(back_populates="likes")


class Notification(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "notifications"

    user_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    type: Mapped[NotificationType] = mapped_column(
        SAEnum(NotificationType, name="notification_type"), nullable=False
    )
    content: Mapped[str] = mapped_column(String(512), nullable=False)
    is_read: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    related_bet_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("bets.id"))

    user: Mapped["User"] = relationship(back_populates="notifications")
