"""
Import every model module here so that:
  1. `Base.metadata.create_all()` picks up all tables.
  2. Alembic's `--autogenerate` can see the full schema.
  3. Cross-model relationship() string references resolve correctly.
"""
from app.models.user import User
from app.models.sports import Sport, Competition, Team, Event, Market, Bookmaker, EventStatus
from app.models.bet import (
    Bet,
    BetSelection,
    Slip,
    SlipImage,
    OCRResult,
    BetStatus,
    BetType,
    SelectionResult,
    SlipStatus,
)
from app.models.social import Follower, Comment, Like, Notification, NotificationType

__all__ = [
    "User",
    "Sport",
    "Competition",
    "Team",
    "Event",
    "Market",
    "Bookmaker",
    "EventStatus",
    "Bet",
    "BetSelection",
    "Slip",
    "SlipImage",
    "OCRResult",
    "BetStatus",
    "BetType",
    "SelectionResult",
    "SlipStatus",
    "Follower",
    "Comment",
    "Like",
    "Notification",
    "NotificationType",
]
